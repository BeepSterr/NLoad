<?php if($NLoad_header == true){ ?>

	<div class="spacer"></div>

	<div class="box" id="module_header">
	
		<p><?php echo $NLoad_servername; ?></p>
		<h6><?php echo $map; ?></h6>
		
	</div>
	
<?php }