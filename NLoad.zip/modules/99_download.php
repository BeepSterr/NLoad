<?php if($NLoad_download == true){ ?>

	<div class="spacer"></div>
	
	<div class="box" id="module_downloads">
	<div class="dl1">
		<p>downloading:</p>
		<p id="dltext">Nothing</p>
	</div>

	<div class="dl2">
		<h1><span id="dlp">0</span>%</h1>
	</div>
				
	<div id="module_download_progressbar_background"><div id="module_download_progressbar"></div></div></div>

	<?php }