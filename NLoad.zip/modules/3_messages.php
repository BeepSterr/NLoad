<?php if($NLoad_msg_enable == true){ ?>

	<div class="spacer"></div>
		<div class="box" id="module_messages">
		
			<h4> <span class="f2" id="module_msg_text" ><?php shuffle($Nload_msg_list); echo $Nload_msg_list[0]; ?></span> </h4>
		
		</div>
			
<?php }