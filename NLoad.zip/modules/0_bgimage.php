<?php if($NLoad_bgimage == true){ ?>
	
	<div>

<style>
  html { background-image: url(<?php echo $NLoad_bgimg;?>); }
</style>
	
	</div>
<?php }